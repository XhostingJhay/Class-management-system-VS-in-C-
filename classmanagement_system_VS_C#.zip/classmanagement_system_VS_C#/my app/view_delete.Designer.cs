﻿namespace my_app
{
    partial class view_delete
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(view_delete));
            this.btn_cancel = new System.Windows.Forms.PictureBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.iDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.usernameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.passwordDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.miDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.secLevelDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.contactDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.genderDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.userAccountBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.nstp_DataSet13 = new my_app.nstp_DataSet13();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btn_search = new System.Windows.Forms.PictureBox();
            this.txtbox_serach = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.nstp_DataSet12 = new my_app.nstp_DataSet12();
            this.userAccountBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.userAccountTableAdapter = new my_app.nstp_DataSet12TableAdapters.UserAccountTableAdapter();
            this.userAccountTableAdapter1 = new my_app.nstp_DataSet13TableAdapters.UserAccountTableAdapter();
            this._MANSMS_DATABASEDataSet = new my_app._MANSMS_DATABASEDataSet();
            this.userAccountBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.userAccountTableAdapter2 = new my_app._MANSMS_DATABASEDataSetTableAdapters.UserAccountTableAdapter();
            this._MANSMS_DATABASEDataSet1 = new my_app._MANSMS_DATABASEDataSet1();
            this.userAccountBindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            this.userAccountTableAdapter3 = new my_app._MANSMS_DATABASEDataSet1TableAdapters.UserAccountTableAdapter();
            this._MANSMS_DATABASEDataSet2 = new my_app._MANSMS_DATABASEDataSet2();
            this.userAccountBindingSource4 = new System.Windows.Forms.BindingSource(this.components);
            this.userAccountTableAdapter4 = new my_app._MANSMS_DATABASEDataSet2TableAdapters.UserAccountTableAdapter();
            this._MANSMS_DATABASEDataSet3 = new my_app._MANSMS_DATABASEDataSet3();
            this.userAccountBindingSource5 = new System.Windows.Forms.BindingSource(this.components);
            this.userAccountTableAdapter5 = new my_app._MANSMS_DATABASEDataSet3TableAdapters.UserAccountTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.btn_cancel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.userAccountBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nstp_DataSet13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btn_search)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nstp_DataSet12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.userAccountBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._MANSMS_DATABASEDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.userAccountBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._MANSMS_DATABASEDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.userAccountBindingSource3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._MANSMS_DATABASEDataSet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.userAccountBindingSource4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._MANSMS_DATABASEDataSet3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.userAccountBindingSource5)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_cancel
            // 
            this.btn_cancel.BackColor = System.Drawing.Color.Transparent;
            this.btn_cancel.Image = ((System.Drawing.Image)(resources.GetObject("btn_cancel.Image")));
            this.btn_cancel.Location = new System.Drawing.Point(749, 333);
            this.btn_cancel.Name = "btn_cancel";
            this.btn_cancel.Size = new System.Drawing.Size(39, 37);
            this.btn_cancel.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.btn_cancel.TabIndex = 42;
            this.btn_cancel.TabStop = false;
            this.btn_cancel.Click += new System.EventHandler(this.btn_cancel_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iDDataGridViewTextBoxColumn,
            this.usernameDataGridViewTextBoxColumn,
            this.passwordDataGridViewTextBoxColumn,
            this.fnameDataGridViewTextBoxColumn,
            this.miDataGridViewTextBoxColumn,
            this.lnameDataGridViewTextBoxColumn,
            this.secLevelDataGridViewTextBoxColumn,
            this.contactDataGridViewTextBoxColumn,
            this.genderDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.userAccountBindingSource5;
            this.dataGridView1.Location = new System.Drawing.Point(12, 12);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(767, 308);
            this.dataGridView1.TabIndex = 43;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // iDDataGridViewTextBoxColumn
            // 
            this.iDDataGridViewTextBoxColumn.DataPropertyName = "ID";
            this.iDDataGridViewTextBoxColumn.HeaderText = "ID";
            this.iDDataGridViewTextBoxColumn.Name = "iDDataGridViewTextBoxColumn";
            // 
            // usernameDataGridViewTextBoxColumn
            // 
            this.usernameDataGridViewTextBoxColumn.DataPropertyName = "username";
            this.usernameDataGridViewTextBoxColumn.HeaderText = "username";
            this.usernameDataGridViewTextBoxColumn.Name = "usernameDataGridViewTextBoxColumn";
            // 
            // passwordDataGridViewTextBoxColumn
            // 
            this.passwordDataGridViewTextBoxColumn.DataPropertyName = "password";
            this.passwordDataGridViewTextBoxColumn.HeaderText = "password";
            this.passwordDataGridViewTextBoxColumn.Name = "passwordDataGridViewTextBoxColumn";
            // 
            // fnameDataGridViewTextBoxColumn
            // 
            this.fnameDataGridViewTextBoxColumn.DataPropertyName = "fname";
            this.fnameDataGridViewTextBoxColumn.HeaderText = "fname";
            this.fnameDataGridViewTextBoxColumn.Name = "fnameDataGridViewTextBoxColumn";
            // 
            // miDataGridViewTextBoxColumn
            // 
            this.miDataGridViewTextBoxColumn.DataPropertyName = "mi";
            this.miDataGridViewTextBoxColumn.HeaderText = "mi";
            this.miDataGridViewTextBoxColumn.Name = "miDataGridViewTextBoxColumn";
            // 
            // lnameDataGridViewTextBoxColumn
            // 
            this.lnameDataGridViewTextBoxColumn.DataPropertyName = "lname";
            this.lnameDataGridViewTextBoxColumn.HeaderText = "lname";
            this.lnameDataGridViewTextBoxColumn.Name = "lnameDataGridViewTextBoxColumn";
            // 
            // secLevelDataGridViewTextBoxColumn
            // 
            this.secLevelDataGridViewTextBoxColumn.DataPropertyName = "Sec_Level";
            this.secLevelDataGridViewTextBoxColumn.HeaderText = "Sec_Level";
            this.secLevelDataGridViewTextBoxColumn.Name = "secLevelDataGridViewTextBoxColumn";
            // 
            // contactDataGridViewTextBoxColumn
            // 
            this.contactDataGridViewTextBoxColumn.DataPropertyName = "contact";
            this.contactDataGridViewTextBoxColumn.HeaderText = "contact";
            this.contactDataGridViewTextBoxColumn.Name = "contactDataGridViewTextBoxColumn";
            // 
            // genderDataGridViewTextBoxColumn
            // 
            this.genderDataGridViewTextBoxColumn.DataPropertyName = "gender";
            this.genderDataGridViewTextBoxColumn.HeaderText = "gender";
            this.genderDataGridViewTextBoxColumn.Name = "genderDataGridViewTextBoxColumn";
            // 
            // userAccountBindingSource1
            // 
            this.userAccountBindingSource1.DataMember = "UserAccount";
            this.userAccountBindingSource1.DataSource = this.nstp_DataSet13;
            // 
            // nstp_DataSet13
            // 
            this.nstp_DataSet13.DataSetName = "nstp_DataSet13";
            this.nstp_DataSet13.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Location = new System.Drawing.Point(574, 323);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(49, 13);
            this.label4.TabIndex = 47;
            this.label4.Text = "DELETE";
            this.label4.Visible = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Location = new System.Drawing.Point(305, 8);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(105, 13);
            this.label3.TabIndex = 46;
            this.label3.Text = "RESEARCH FOR ID";
            this.label3.Visible = false;
            // 
            // btn_search
            // 
            this.btn_search.BackColor = System.Drawing.Color.Transparent;
            this.btn_search.Image = ((System.Drawing.Image)(resources.GetObject("btn_search.Image")));
            this.btn_search.Location = new System.Drawing.Point(579, 337);
            this.btn_search.Name = "btn_search";
            this.btn_search.Size = new System.Drawing.Size(37, 32);
            this.btn_search.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.btn_search.TabIndex = 45;
            this.btn_search.TabStop = false;
            this.btn_search.Click += new System.EventHandler(this.btn_search_Click);
            // 
            // txtbox_serach
            // 
            this.txtbox_serach.AccessibleName = "";
            this.txtbox_serach.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbox_serach.Location = new System.Drawing.Point(202, 24);
            this.txtbox_serach.Name = "txtbox_serach";
            this.txtbox_serach.Size = new System.Drawing.Size(291, 26);
            this.txtbox_serach.TabIndex = 44;
            this.txtbox_serach.Tag = "Search";
            this.txtbox_serach.Visible = false;
            this.txtbox_serach.TextChanged += new System.EventHandler(this.txtbox_serach_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Location = new System.Drawing.Point(640, 323);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(58, 13);
            this.label1.TabIndex = 49;
            this.label1.Text = "REFRESH";
            this.label1.Visible = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(651, 337);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(37, 32);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 48;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // nstp_DataSet12
            // 
            this.nstp_DataSet12.DataSetName = "nstp_DataSet12";
            this.nstp_DataSet12.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // userAccountBindingSource
            // 
            this.userAccountBindingSource.DataMember = "UserAccount";
            this.userAccountBindingSource.DataSource = this.nstp_DataSet12;
            // 
            // userAccountTableAdapter
            // 
            this.userAccountTableAdapter.ClearBeforeFill = true;
            // 
            // userAccountTableAdapter1
            // 
            this.userAccountTableAdapter1.ClearBeforeFill = true;
            // 
            // _MANSMS_DATABASEDataSet
            // 
            this._MANSMS_DATABASEDataSet.DataSetName = "_MANSMS_DATABASEDataSet";
            this._MANSMS_DATABASEDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // userAccountBindingSource2
            // 
            this.userAccountBindingSource2.DataMember = "UserAccount";
            this.userAccountBindingSource2.DataSource = this._MANSMS_DATABASEDataSet;
            // 
            // userAccountTableAdapter2
            // 
            this.userAccountTableAdapter2.ClearBeforeFill = true;
            // 
            // _MANSMS_DATABASEDataSet1
            // 
            this._MANSMS_DATABASEDataSet1.DataSetName = "_MANSMS_DATABASEDataSet1";
            this._MANSMS_DATABASEDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // userAccountBindingSource3
            // 
            this.userAccountBindingSource3.DataMember = "UserAccount";
            this.userAccountBindingSource3.DataSource = this._MANSMS_DATABASEDataSet1;
            // 
            // userAccountTableAdapter3
            // 
            this.userAccountTableAdapter3.ClearBeforeFill = true;
            // 
            // _MANSMS_DATABASEDataSet2
            // 
            this._MANSMS_DATABASEDataSet2.DataSetName = "_MANSMS_DATABASEDataSet2";
            this._MANSMS_DATABASEDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // userAccountBindingSource4
            // 
            this.userAccountBindingSource4.DataMember = "UserAccount";
            this.userAccountBindingSource4.DataSource = this._MANSMS_DATABASEDataSet2;
            // 
            // userAccountTableAdapter4
            // 
            this.userAccountTableAdapter4.ClearBeforeFill = true;
            // 
            // _MANSMS_DATABASEDataSet3
            // 
            this._MANSMS_DATABASEDataSet3.DataSetName = "_MANSMS_DATABASEDataSet3";
            this._MANSMS_DATABASEDataSet3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // userAccountBindingSource5
            // 
            this.userAccountBindingSource5.DataMember = "UserAccount";
            this.userAccountBindingSource5.DataSource = this._MANSMS_DATABASEDataSet3;
            // 
            // userAccountTableAdapter5
            // 
            this.userAccountTableAdapter5.ClearBeforeFill = true;
            // 
            // view_delete
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(791, 373);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btn_search);
            this.Controls.Add(this.txtbox_serach);
            this.Controls.Add(this.btn_cancel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "view_delete";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "view_delete";
            this.Load += new System.EventHandler(this.view_delete_Load);
            ((System.ComponentModel.ISupportInitialize)(this.btn_cancel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.userAccountBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nstp_DataSet13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btn_search)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nstp_DataSet12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.userAccountBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._MANSMS_DATABASEDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.userAccountBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._MANSMS_DATABASEDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.userAccountBindingSource3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._MANSMS_DATABASEDataSet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.userAccountBindingSource4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._MANSMS_DATABASEDataSet3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.userAccountBindingSource5)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox btn_cancel;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox btn_search;
        private System.Windows.Forms.TextBox txtbox_serach;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private nstp_DataSet12 nstp_DataSet12;
        private System.Windows.Forms.BindingSource userAccountBindingSource;
        private nstp_DataSet12TableAdapters.UserAccountTableAdapter userAccountTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn usernameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn passwordDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn fnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn miDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn lnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn secLevelDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn contactDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn genderDataGridViewTextBoxColumn;
        private nstp_DataSet13 nstp_DataSet13;
        private System.Windows.Forms.BindingSource userAccountBindingSource1;
        private nstp_DataSet13TableAdapters.UserAccountTableAdapter userAccountTableAdapter1;
        private _MANSMS_DATABASEDataSet _MANSMS_DATABASEDataSet;
        private System.Windows.Forms.BindingSource userAccountBindingSource2;
        private _MANSMS_DATABASEDataSetTableAdapters.UserAccountTableAdapter userAccountTableAdapter2;
        private _MANSMS_DATABASEDataSet1 _MANSMS_DATABASEDataSet1;
        private System.Windows.Forms.BindingSource userAccountBindingSource3;
        private _MANSMS_DATABASEDataSet1TableAdapters.UserAccountTableAdapter userAccountTableAdapter3;
        private _MANSMS_DATABASEDataSet2 _MANSMS_DATABASEDataSet2;
        private System.Windows.Forms.BindingSource userAccountBindingSource4;
        private _MANSMS_DATABASEDataSet2TableAdapters.UserAccountTableAdapter userAccountTableAdapter4;
        private _MANSMS_DATABASEDataSet3 _MANSMS_DATABASEDataSet3;
        private System.Windows.Forms.BindingSource userAccountBindingSource5;
        private _MANSMS_DATABASEDataSet3TableAdapters.UserAccountTableAdapter userAccountTableAdapter5;
    }
}