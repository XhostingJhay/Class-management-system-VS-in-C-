﻿namespace my_app
{
    partial class admincon
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(admincon));
            this.fontDialog1 = new System.Windows.Forms.FontDialog();
            this.btn_back = new System.Windows.Forms.PictureBox();
            this.studentBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.nstp_DataSet14 = new my_app.nstp_DataSet14();
            this.studentBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.nstp_DataSet2 = new my_app.nstp_DataSet2();
            this.nstp_DataSet = new my_app.nstp_DataSet();
            this.nstpDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.studentBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.studentTableAdapter = new my_app.nstp_DataSetTableAdapters.studentTableAdapter();
            this.studentTableAdapter1 = new my_app.nstp_DataSet2TableAdapters.studentTableAdapter();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtbox_serach = new System.Windows.Forms.TextBox();
            this.btn_search = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.studentTableAdapter2 = new my_app.nstp_DataSet14TableAdapters.studentTableAdapter();
            this.nstp_DataSet17 = new my_app.nstp_DataSet17();
            this.studentBindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            this.studentTableAdapter3 = new my_app.nstp_DataSet17TableAdapters.studentTableAdapter();
            this.nstp_DataSet18 = new my_app.nstp_DataSet18();
            this.studentBindingSource4 = new System.Windows.Forms.BindingSource(this.components);
            this.studentTableAdapter4 = new my_app.nstp_DataSet18TableAdapters.studentTableAdapter();
            this.nstp_DataSet19 = new my_app.nstp_DataSet19();
            this.studentBindingSource5 = new System.Windows.Forms.BindingSource(this.components);
            this.studentTableAdapter5 = new my_app.nstp_DataSet19TableAdapters.studentTableAdapter();
            this.nstp_DataSet20 = new my_app.nstp_DataSet20();
            this.studentBindingSource6 = new System.Windows.Forms.BindingSource(this.components);
            this.studentTableAdapter6 = new my_app.nstp_DataSet20TableAdapters.studentTableAdapter();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.nstp_DataSet21 = new my_app.nstp_DataSet21();
            this.studentBindingSource7 = new System.Windows.Forms.BindingSource(this.components);
            this.studentTableAdapter7 = new my_app.nstp_DataSet21TableAdapters.studentTableAdapter();
            this.iDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.surnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.firstnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mIDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.semesterDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.courseDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.yearDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.statusDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.prilemDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.midtermDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.finalsDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.averageDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sectionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.profDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.btn_back)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nstp_DataSet14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nstp_DataSet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nstp_DataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nstpDataSetBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btn_search)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nstp_DataSet17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentBindingSource3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nstp_DataSet18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentBindingSource4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nstp_DataSet19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentBindingSource5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nstp_DataSet20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentBindingSource6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nstp_DataSet21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentBindingSource7)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_back
            // 
            this.btn_back.Image = ((System.Drawing.Image)(resources.GetObject("btn_back.Image")));
            this.btn_back.Location = new System.Drawing.Point(809, 268);
            this.btn_back.Name = "btn_back";
            this.btn_back.Size = new System.Drawing.Size(37, 34);
            this.btn_back.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.btn_back.TabIndex = 1;
            this.btn_back.TabStop = false;
            this.btn_back.Click += new System.EventHandler(this.btn_back_Click);
            // 
            // studentBindingSource2
            // 
            this.studentBindingSource2.DataMember = "student";
            this.studentBindingSource2.DataSource = this.nstp_DataSet14;
            // 
            // nstp_DataSet14
            // 
            this.nstp_DataSet14.DataSetName = "nstp_DataSet14";
            this.nstp_DataSet14.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // studentBindingSource1
            // 
            this.studentBindingSource1.DataMember = "student";
            this.studentBindingSource1.DataSource = this.nstp_DataSet2;
            // 
            // nstp_DataSet2
            // 
            this.nstp_DataSet2.DataSetName = "nstp_DataSet2";
            this.nstp_DataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // nstp_DataSet
            // 
            this.nstp_DataSet.DataSetName = "nstp_DataSet";
            this.nstp_DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // nstpDataSetBindingSource
            // 
            this.nstpDataSetBindingSource.DataSource = this.nstp_DataSet;
            this.nstpDataSetBindingSource.Position = 0;
            // 
            // studentBindingSource
            // 
            this.studentBindingSource.DataMember = "student";
            this.studentBindingSource.DataSource = this.nstpDataSetBindingSource;
            // 
            // studentTableAdapter
            // 
            this.studentTableAdapter.ClearBeforeFill = true;
            // 
            // studentTableAdapter1
            // 
            this.studentTableAdapter1.ClearBeforeFill = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 6);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(378, 55);
            this.label1.TabIndex = 3;
            this.label1.Text = "VIEW STUDENT";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 289);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(74, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Back to Menu";
            this.label2.Visible = false;
            // 
            // txtbox_serach
            // 
            this.txtbox_serach.AccessibleName = "";
            this.txtbox_serach.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbox_serach.Location = new System.Drawing.Point(429, 27);
            this.txtbox_serach.Name = "txtbox_serach";
            this.txtbox_serach.Size = new System.Drawing.Size(168, 26);
            this.txtbox_serach.TabIndex = 5;
            this.txtbox_serach.Tag = "Search";
            this.txtbox_serach.TextChanged += new System.EventHandler(this.txtbox_serach_TextChanged);
            // 
            // btn_search
            // 
            this.btn_search.Image = ((System.Drawing.Image)(resources.GetObject("btn_search.Image")));
            this.btn_search.Location = new System.Drawing.Point(766, 27);
            this.btn_search.Name = "btn_search";
            this.btn_search.Size = new System.Drawing.Size(37, 32);
            this.btn_search.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.btn_search.TabIndex = 6;
            this.btn_search.TabStop = false;
            this.btn_search.Click += new System.EventHandler(this.btn_search_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(461, 13);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(105, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "RESEARCH FOR ID";
            this.label3.Visible = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(755, 13);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(58, 13);
            this.label4.TabIndex = 8;
            this.label4.Text = "REFRESH";
            this.label4.Visible = false;
            // 
            // studentTableAdapter2
            // 
            this.studentTableAdapter2.ClearBeforeFill = true;
            // 
            // nstp_DataSet17
            // 
            this.nstp_DataSet17.DataSetName = "nstp_DataSet17";
            this.nstp_DataSet17.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // studentBindingSource3
            // 
            this.studentBindingSource3.DataMember = "student";
            this.studentBindingSource3.DataSource = this.nstp_DataSet17;
            // 
            // studentTableAdapter3
            // 
            this.studentTableAdapter3.ClearBeforeFill = true;
            // 
            // nstp_DataSet18
            // 
            this.nstp_DataSet18.DataSetName = "nstp_DataSet18";
            this.nstp_DataSet18.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // studentBindingSource4
            // 
            this.studentBindingSource4.DataMember = "student";
            this.studentBindingSource4.DataSource = this.nstp_DataSet18;
            // 
            // studentTableAdapter4
            // 
            this.studentTableAdapter4.ClearBeforeFill = true;
            // 
            // nstp_DataSet19
            // 
            this.nstp_DataSet19.DataSetName = "nstp_DataSet19";
            this.nstp_DataSet19.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // studentBindingSource5
            // 
            this.studentBindingSource5.DataMember = "student";
            this.studentBindingSource5.DataSource = this.nstp_DataSet19;
            // 
            // studentTableAdapter5
            // 
            this.studentTableAdapter5.ClearBeforeFill = true;
            // 
            // nstp_DataSet20
            // 
            this.nstp_DataSet20.DataSetName = "nstp_DataSet20";
            this.nstp_DataSet20.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // studentBindingSource6
            // 
            this.studentBindingSource6.DataMember = "student";
            this.studentBindingSource6.DataSource = this.nstp_DataSet20;
            // 
            // studentTableAdapter6
            // 
            this.studentTableAdapter6.ClearBeforeFill = true;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iDDataGridViewTextBoxColumn,
            this.surnameDataGridViewTextBoxColumn,
            this.firstnameDataGridViewTextBoxColumn,
            this.mIDataGridViewTextBoxColumn,
            this.semesterDataGridViewTextBoxColumn,
            this.dateDataGridViewTextBoxColumn,
            this.courseDataGridViewTextBoxColumn,
            this.yearDataGridViewTextBoxColumn,
            this.statusDataGridViewTextBoxColumn,
            this.prilemDataGridViewTextBoxColumn,
            this.midtermDataGridViewTextBoxColumn,
            this.finalsDataGridViewTextBoxColumn,
            this.averageDataGridViewTextBoxColumn,
            this.sectionDataGridViewTextBoxColumn,
            this.profDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.studentBindingSource7;
            this.dataGridView1.Location = new System.Drawing.Point(7, 61);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(838, 201);
            this.dataGridView1.TabIndex = 12;
            // 
            // nstp_DataSet21
            // 
            this.nstp_DataSet21.DataSetName = "nstp_DataSet21";
            this.nstp_DataSet21.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // studentBindingSource7
            // 
            this.studentBindingSource7.DataMember = "student";
            this.studentBindingSource7.DataSource = this.nstp_DataSet21;
            // 
            // studentTableAdapter7
            // 
            this.studentTableAdapter7.ClearBeforeFill = true;
            // 
            // iDDataGridViewTextBoxColumn
            // 
            this.iDDataGridViewTextBoxColumn.DataPropertyName = "ID";
            this.iDDataGridViewTextBoxColumn.HeaderText = "ID";
            this.iDDataGridViewTextBoxColumn.Name = "iDDataGridViewTextBoxColumn";
            // 
            // surnameDataGridViewTextBoxColumn
            // 
            this.surnameDataGridViewTextBoxColumn.DataPropertyName = "Surname";
            this.surnameDataGridViewTextBoxColumn.HeaderText = "Surname";
            this.surnameDataGridViewTextBoxColumn.Name = "surnameDataGridViewTextBoxColumn";
            // 
            // firstnameDataGridViewTextBoxColumn
            // 
            this.firstnameDataGridViewTextBoxColumn.DataPropertyName = "Firstname";
            this.firstnameDataGridViewTextBoxColumn.HeaderText = "Firstname";
            this.firstnameDataGridViewTextBoxColumn.Name = "firstnameDataGridViewTextBoxColumn";
            // 
            // mIDataGridViewTextBoxColumn
            // 
            this.mIDataGridViewTextBoxColumn.DataPropertyName = "MI";
            this.mIDataGridViewTextBoxColumn.HeaderText = "MI";
            this.mIDataGridViewTextBoxColumn.Name = "mIDataGridViewTextBoxColumn";
            // 
            // semesterDataGridViewTextBoxColumn
            // 
            this.semesterDataGridViewTextBoxColumn.DataPropertyName = "Semester";
            this.semesterDataGridViewTextBoxColumn.HeaderText = "Semester";
            this.semesterDataGridViewTextBoxColumn.Name = "semesterDataGridViewTextBoxColumn";
            // 
            // dateDataGridViewTextBoxColumn
            // 
            this.dateDataGridViewTextBoxColumn.DataPropertyName = "Date";
            this.dateDataGridViewTextBoxColumn.HeaderText = "Date";
            this.dateDataGridViewTextBoxColumn.Name = "dateDataGridViewTextBoxColumn";
            // 
            // courseDataGridViewTextBoxColumn
            // 
            this.courseDataGridViewTextBoxColumn.DataPropertyName = "Course";
            this.courseDataGridViewTextBoxColumn.HeaderText = "Course";
            this.courseDataGridViewTextBoxColumn.Name = "courseDataGridViewTextBoxColumn";
            // 
            // yearDataGridViewTextBoxColumn
            // 
            this.yearDataGridViewTextBoxColumn.DataPropertyName = "Year";
            this.yearDataGridViewTextBoxColumn.HeaderText = "Year";
            this.yearDataGridViewTextBoxColumn.Name = "yearDataGridViewTextBoxColumn";
            // 
            // statusDataGridViewTextBoxColumn
            // 
            this.statusDataGridViewTextBoxColumn.DataPropertyName = "Status";
            this.statusDataGridViewTextBoxColumn.HeaderText = "Status";
            this.statusDataGridViewTextBoxColumn.Name = "statusDataGridViewTextBoxColumn";
            // 
            // prilemDataGridViewTextBoxColumn
            // 
            this.prilemDataGridViewTextBoxColumn.DataPropertyName = "Prilem";
            this.prilemDataGridViewTextBoxColumn.HeaderText = "Prilem";
            this.prilemDataGridViewTextBoxColumn.Name = "prilemDataGridViewTextBoxColumn";
            // 
            // midtermDataGridViewTextBoxColumn
            // 
            this.midtermDataGridViewTextBoxColumn.DataPropertyName = "Midterm";
            this.midtermDataGridViewTextBoxColumn.HeaderText = "Midterm";
            this.midtermDataGridViewTextBoxColumn.Name = "midtermDataGridViewTextBoxColumn";
            // 
            // finalsDataGridViewTextBoxColumn
            // 
            this.finalsDataGridViewTextBoxColumn.DataPropertyName = "Finals";
            this.finalsDataGridViewTextBoxColumn.HeaderText = "Finals";
            this.finalsDataGridViewTextBoxColumn.Name = "finalsDataGridViewTextBoxColumn";
            // 
            // averageDataGridViewTextBoxColumn
            // 
            this.averageDataGridViewTextBoxColumn.DataPropertyName = "Average";
            this.averageDataGridViewTextBoxColumn.HeaderText = "Average";
            this.averageDataGridViewTextBoxColumn.Name = "averageDataGridViewTextBoxColumn";
            // 
            // sectionDataGridViewTextBoxColumn
            // 
            this.sectionDataGridViewTextBoxColumn.DataPropertyName = "Section";
            this.sectionDataGridViewTextBoxColumn.HeaderText = "Section";
            this.sectionDataGridViewTextBoxColumn.Name = "sectionDataGridViewTextBoxColumn";
            // 
            // profDataGridViewTextBoxColumn
            // 
            this.profDataGridViewTextBoxColumn.DataPropertyName = "Prof";
            this.profDataGridViewTextBoxColumn.HeaderText = "Prof";
            this.profDataGridViewTextBoxColumn.Name = "profDataGridViewTextBoxColumn";
            // 
            // admincon
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(229)))), ((int)(((byte)(125)))));
            this.ClientSize = new System.Drawing.Size(853, 305);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btn_search);
            this.Controls.Add(this.txtbox_serach);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_back);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "admincon";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "admincon";
            this.Load += new System.EventHandler(this.admincon_Load);
            ((System.ComponentModel.ISupportInitialize)(this.btn_back)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nstp_DataSet14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nstp_DataSet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nstp_DataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nstpDataSetBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btn_search)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nstp_DataSet17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentBindingSource3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nstp_DataSet18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentBindingSource4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nstp_DataSet19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentBindingSource5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nstp_DataSet20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentBindingSource6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nstp_DataSet21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentBindingSource7)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.FontDialog fontDialog1;
        private System.Windows.Forms.PictureBox btn_back;
        private System.Windows.Forms.BindingSource nstpDataSetBindingSource;
        private nstp_DataSet nstp_DataSet;
        private System.Windows.Forms.BindingSource studentBindingSource;
        private nstp_DataSetTableAdapters.studentTableAdapter studentTableAdapter;
        private nstp_DataSet2 nstp_DataSet2;
        private System.Windows.Forms.BindingSource studentBindingSource1;
        private nstp_DataSet2TableAdapters.studentTableAdapter studentTableAdapter1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtbox_serach;
        private System.Windows.Forms.PictureBox btn_search;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private nstp_DataSet14 nstp_DataSet14;
        private System.Windows.Forms.BindingSource studentBindingSource2;
        private nstp_DataSet14TableAdapters.studentTableAdapter studentTableAdapter2;
        private nstp_DataSet17 nstp_DataSet17;
        private System.Windows.Forms.BindingSource studentBindingSource3;
        private nstp_DataSet17TableAdapters.studentTableAdapter studentTableAdapter3;
        private nstp_DataSet18 nstp_DataSet18;
        private System.Windows.Forms.BindingSource studentBindingSource4;
        private nstp_DataSet18TableAdapters.studentTableAdapter studentTableAdapter4;
        private nstp_DataSet19 nstp_DataSet19;
        private System.Windows.Forms.BindingSource studentBindingSource5;
        private nstp_DataSet19TableAdapters.studentTableAdapter studentTableAdapter5;
        private nstp_DataSet20 nstp_DataSet20;
        private System.Windows.Forms.BindingSource studentBindingSource6;
        private nstp_DataSet20TableAdapters.studentTableAdapter studentTableAdapter6;
        private System.Windows.Forms.DataGridView dataGridView1;
        private nstp_DataSet21 nstp_DataSet21;
        private System.Windows.Forms.BindingSource studentBindingSource7;
        private nstp_DataSet21TableAdapters.studentTableAdapter studentTableAdapter7;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn surnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn firstnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn mIDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn semesterDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn courseDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn yearDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn statusDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn prilemDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn midtermDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn finalsDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn averageDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sectionDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn profDataGridViewTextBoxColumn;

    }
}