﻿namespace my_app
{
    partial class register
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(register));
            this.txtbox_ID = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtbox_surename = new System.Windows.Forms.TextBox();
            this.txtbox_firstname = new System.Windows.Forms.TextBox();
            this.txtbox_MI = new System.Windows.Forms.TextBox();
            this.txtbox_sem = new System.Windows.Forms.TextBox();
            this.txtbox_yr = new System.Windows.Forms.TextBox();
            this.txtbox_course = new System.Windows.Forms.TextBox();
            this.txtbox_year = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.btn_add = new System.Windows.Forms.PictureBox();
            this.btn_cancel = new System.Windows.Forms.PictureBox();
            this.txtbox_status = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.txt_average = new System.Windows.Forms.TextBox();
            this.txt_midterm = new System.Windows.Forms.TextBox();
            this.txt_finals = new System.Windows.Forms.TextBox();
            this.txt_prilem = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.btn_add)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btn_cancel)).BeginInit();
            this.SuspendLayout();
            // 
            // txtbox_ID
            // 
            this.txtbox_ID.Location = new System.Drawing.Point(12, 25);
            this.txtbox_ID.Name = "txtbox_ID";
            this.txtbox_ID.Size = new System.Drawing.Size(105, 20);
            this.txtbox_ID.TabIndex = 0;
            this.txtbox_ID.TextChanged += new System.EventHandler(this.txtbox_ID_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(50, 48);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(38, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "ID No.";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 79);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Name";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(121, 102);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(55, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "Surename";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(340, 102);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(57, 13);
            this.label4.TabIndex = 4;
            this.label4.Text = "First Name";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(484, 102);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(22, 13);
            this.label5.TabIndex = 5;
            this.label5.Text = "MI.";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(235, 154);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(40, 13);
            this.label6.TabIndex = 6;
            this.label6.Text = "Course";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // txtbox_surename
            // 
            this.txtbox_surename.Location = new System.Drawing.Point(53, 79);
            this.txtbox_surename.Name = "txtbox_surename";
            this.txtbox_surename.Size = new System.Drawing.Size(198, 20);
            this.txtbox_surename.TabIndex = 7;
            this.txtbox_surename.TextChanged += new System.EventHandler(this.txtbox_surename_TextChanged);
            // 
            // txtbox_firstname
            // 
            this.txtbox_firstname.Location = new System.Drawing.Point(257, 79);
            this.txtbox_firstname.Name = "txtbox_firstname";
            this.txtbox_firstname.Size = new System.Drawing.Size(205, 20);
            this.txtbox_firstname.TabIndex = 8;
            this.txtbox_firstname.TextChanged += new System.EventHandler(this.txtbox_firstname_TextChanged);
            // 
            // txtbox_MI
            // 
            this.txtbox_MI.Location = new System.Drawing.Point(468, 79);
            this.txtbox_MI.Name = "txtbox_MI";
            this.txtbox_MI.Size = new System.Drawing.Size(53, 20);
            this.txtbox_MI.TabIndex = 9;
            this.txtbox_MI.TextChanged += new System.EventHandler(this.txtbox_MI_TextChanged);
            // 
            // txtbox_sem
            // 
            this.txtbox_sem.Location = new System.Drawing.Point(53, 147);
            this.txtbox_sem.Name = "txtbox_sem";
            this.txtbox_sem.Size = new System.Drawing.Size(39, 20);
            this.txtbox_sem.TabIndex = 10;
            this.txtbox_sem.TextChanged += new System.EventHandler(this.txtbox_sem_TextChanged);
            // 
            // txtbox_yr
            // 
            this.txtbox_yr.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(229)))), ((int)(((byte)(125)))));
            this.txtbox_yr.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtbox_yr.Location = new System.Drawing.Point(162, 154);
            this.txtbox_yr.Name = "txtbox_yr";
            this.txtbox_yr.Size = new System.Drawing.Size(67, 13);
            this.txtbox_yr.TabIndex = 11;
            this.txtbox_yr.Text = "2019 - 2020";
            this.txtbox_yr.TextChanged += new System.EventHandler(this.txtbox_yr_TextChanged);
            // 
            // txtbox_course
            // 
            this.txtbox_course.Location = new System.Drawing.Point(281, 147);
            this.txtbox_course.Name = "txtbox_course";
            this.txtbox_course.Size = new System.Drawing.Size(80, 20);
            this.txtbox_course.TabIndex = 12;
            this.txtbox_course.TextChanged += new System.EventHandler(this.txtbox_course_TextChanged);
            // 
            // txtbox_year
            // 
            this.txtbox_year.Location = new System.Drawing.Point(402, 147);
            this.txtbox_year.Name = "txtbox_year";
            this.txtbox_year.Size = new System.Drawing.Size(59, 20);
            this.txtbox_year.TabIndex = 13;
            this.txtbox_year.TextChanged += new System.EventHandler(this.txtbox_year_TextChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(104, 154);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(51, 13);
            this.label7.TabIndex = 14;
            this.label7.Text = "Semester";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(367, 154);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(29, 13);
            this.label8.TabIndex = 15;
            this.label8.Text = "Year";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(171, 19);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(213, 13);
            this.label9.TabIndex = 18;
            this.label9.Text = "PAMANTASAN NG LUNGSOD NG PASAY\r\n";
            this.label9.Click += new System.EventHandler(this.label9_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(181, 35);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(190, 26);
            this.label10.TabIndex = 19;
            this.label10.Text = "Pasadena St. F.B. Harrison, Pasay City\r\n\r\n";
            this.label10.Click += new System.EventHandler(this.label10_Click);
            // 
            // btn_add
            // 
            this.btn_add.Image = ((System.Drawing.Image)(resources.GetObject("btn_add.Image")));
            this.btn_add.Location = new System.Drawing.Point(437, 182);
            this.btn_add.Name = "btn_add";
            this.btn_add.Size = new System.Drawing.Size(39, 38);
            this.btn_add.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.btn_add.TabIndex = 20;
            this.btn_add.TabStop = false;
            this.btn_add.Click += new System.EventHandler(this.btn_add_Click);
            // 
            // btn_cancel
            // 
            this.btn_cancel.Image = ((System.Drawing.Image)(resources.GetObject("btn_cancel.Image")));
            this.btn_cancel.Location = new System.Drawing.Point(482, 183);
            this.btn_cancel.Name = "btn_cancel";
            this.btn_cancel.Size = new System.Drawing.Size(39, 37);
            this.btn_cancel.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.btn_cancel.TabIndex = 21;
            this.btn_cancel.TabStop = false;
            this.btn_cancel.Click += new System.EventHandler(this.btn_cancel_Click_1);
            // 
            // txtbox_status
            // 
            this.txtbox_status.Location = new System.Drawing.Point(472, 147);
            this.txtbox_status.Name = "txtbox_status";
            this.txtbox_status.Size = new System.Drawing.Size(53, 20);
            this.txtbox_status.TabIndex = 22;
            this.txtbox_status.Visible = false;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(429, 154);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(37, 13);
            this.label11.TabIndex = 23;
            this.label11.Text = "Status";
            this.label11.Visible = false;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(9, 207);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(74, 13);
            this.label12.TabIndex = 24;
            this.label12.Text = "Back to Menu";
            this.label12.Visible = false;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(89, 207);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(81, 13);
            this.label13.TabIndex = 25;
            this.label13.Text = "Student Saved!";
            this.label13.Visible = false;
            // 
            // txt_average
            // 
            this.txt_average.Location = new System.Drawing.Point(421, 292);
            this.txt_average.MaxLength = 5;
            this.txt_average.Name = "txt_average";
            this.txt_average.Size = new System.Drawing.Size(83, 20);
            this.txt_average.TabIndex = 62;
            this.txt_average.Visible = false;
            // 
            // txt_midterm
            // 
            this.txt_midterm.Location = new System.Drawing.Point(167, 292);
            this.txt_midterm.Name = "txt_midterm";
            this.txt_midterm.Size = new System.Drawing.Size(83, 20);
            this.txt_midterm.TabIndex = 61;
            this.txt_midterm.Visible = false;
            // 
            // txt_finals
            // 
            this.txt_finals.Location = new System.Drawing.Point(278, 292);
            this.txt_finals.Name = "txt_finals";
            this.txt_finals.Size = new System.Drawing.Size(83, 20);
            this.txt_finals.TabIndex = 60;
            this.txt_finals.Visible = false;
            // 
            // txt_prilem
            // 
            this.txt_prilem.Location = new System.Drawing.Point(47, 292);
            this.txt_prilem.Name = "txt_prilem";
            this.txt_prilem.Size = new System.Drawing.Size(83, 20);
            this.txt_prilem.TabIndex = 59;
            this.txt_prilem.Visible = false;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(425, 29);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(43, 13);
            this.label14.TabIndex = 64;
            this.label14.Text = "Section";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(468, 24);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(64, 21);
            this.comboBox1.TabIndex = 65;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(472, 147);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(53, 20);
            this.textBox1.TabIndex = 66;
            this.textBox1.Visible = false;
            // 
            // register
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(229)))), ((int)(((byte)(125)))));
            this.ClientSize = new System.Drawing.Size(544, 230);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.txt_average);
            this.Controls.Add(this.txt_midterm);
            this.Controls.Add(this.txt_finals);
            this.Controls.Add(this.txt_prilem);
            this.Controls.Add(this.txtbox_year);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.txtbox_status);
            this.Controls.Add(this.btn_cancel);
            this.Controls.Add(this.btn_add);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txtbox_course);
            this.Controls.Add(this.txtbox_yr);
            this.Controls.Add(this.txtbox_sem);
            this.Controls.Add(this.txtbox_MI);
            this.Controls.Add(this.txtbox_firstname);
            this.Controls.Add(this.txtbox_surename);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtbox_ID);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "register";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "register";
            this.Load += new System.EventHandler(this.register_Load);
            ((System.ComponentModel.ISupportInitialize)(this.btn_add)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btn_cancel)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtbox_ID;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtbox_surename;
        private System.Windows.Forms.TextBox txtbox_firstname;
        private System.Windows.Forms.TextBox txtbox_MI;
        private System.Windows.Forms.TextBox txtbox_sem;
        private System.Windows.Forms.TextBox txtbox_yr;
        private System.Windows.Forms.TextBox txtbox_course;
        private System.Windows.Forms.TextBox txtbox_year;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.PictureBox btn_add;
        private System.Windows.Forms.PictureBox btn_cancel;
        private System.Windows.Forms.TextBox txtbox_status;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txt_average;
        private System.Windows.Forms.TextBox txt_midterm;
        private System.Windows.Forms.TextBox txt_finals;
        private System.Windows.Forms.TextBox txt_prilem;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.TextBox textBox1;
    }
}