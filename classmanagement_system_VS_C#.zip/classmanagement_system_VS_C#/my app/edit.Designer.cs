﻿namespace my_app
{
    partial class edit
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(edit));
            this.btn_cancel = new System.Windows.Forms.PictureBox();
            this.btn_update = new System.Windows.Forms.PictureBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.txtbox_year = new System.Windows.Forms.TextBox();
            this.txtbox_course = new System.Windows.Forms.TextBox();
            this.txtbox_yr = new System.Windows.Forms.TextBox();
            this.txtbox_sem = new System.Windows.Forms.TextBox();
            this.txtbox_MI = new System.Windows.Forms.TextBox();
            this.txtbox_firstname = new System.Windows.Forms.TextBox();
            this.txtbox_surename = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtbox_ID = new System.Windows.Forms.TextBox();
            this.txtbox_status = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.studentBindingSource4 = new System.Windows.Forms.BindingSource(this.components);
            this.nstp_DataSet15 = new my_app.nstp_DataSet15();
            this.studentBindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            this.nstp_DataSet6 = new my_app.nstp_DataSet6();
            this.nstp_DataSet5 = new my_app.nstp_DataSet5();
            this.nstp_DataSet4 = new my_app.nstp_DataSet4();
            this.nstp_DataSet3 = new my_app.nstp_DataSet3();
            this.studentBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.studentTableAdapter2 = new my_app.nstp_DataSet3TableAdapters.studentTableAdapter();
            this.nstp_DataSet1 = new my_app.nstp_DataSet1();
            this.studentTableAdapter1 = new my_app.nstp_DataSet1TableAdapters.studentTableAdapter();
            this.studentTableAdapter3 = new my_app.nstp_DataSet6TableAdapters.studentTableAdapter();
            this.studentTableAdapter = new my_app.nstp_DataSetTableAdapters.studentTableAdapter();
            this.nstp_DataSet = new my_app.nstp_DataSet();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.studentBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.studentBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.studentTableAdapter4 = new my_app.nstp_DataSet15TableAdapters.studentTableAdapter();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.nstp_DataSet22 = new my_app.nstp_DataSet22();
            this.studentBindingSource5 = new System.Windows.Forms.BindingSource(this.components);
            this.studentTableAdapter5 = new my_app.nstp_DataSet22TableAdapters.studentTableAdapter();
            this.dataGridtt = new System.Windows.Forms.DataGridView();
            this.nstp_DataSet23 = new my_app.nstp_DataSet23();
            this.studentBindingSource6 = new System.Windows.Forms.BindingSource(this.components);
            this.studentTableAdapter6 = new my_app.nstp_DataSet23TableAdapters.studentTableAdapter();
            this.iDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.surnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.firstnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mIDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.semesterDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.courseDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.yearDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.statusDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.prilemDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.midtermDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.finalsDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.averageDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sectionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.profDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.btn_cancel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btn_update)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentBindingSource4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nstp_DataSet15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentBindingSource3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nstp_DataSet6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nstp_DataSet5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nstp_DataSet4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nstp_DataSet3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nstp_DataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nstp_DataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nstp_DataSet22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentBindingSource5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridtt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nstp_DataSet23)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentBindingSource6)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_cancel
            // 
            this.btn_cancel.Image = ((System.Drawing.Image)(resources.GetObject("btn_cancel.Image")));
            this.btn_cancel.Location = new System.Drawing.Point(485, 452);
            this.btn_cancel.Name = "btn_cancel";
            this.btn_cancel.Size = new System.Drawing.Size(39, 37);
            this.btn_cancel.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.btn_cancel.TabIndex = 41;
            this.btn_cancel.TabStop = false;
            this.btn_cancel.Click += new System.EventHandler(this.btn_cancel_Click_1);
            // 
            // btn_update
            // 
            this.btn_update.Image = ((System.Drawing.Image)(resources.GetObject("btn_update.Image")));
            this.btn_update.Location = new System.Drawing.Point(440, 452);
            this.btn_update.Name = "btn_update";
            this.btn_update.Size = new System.Drawing.Size(39, 38);
            this.btn_update.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.btn_update.TabIndex = 40;
            this.btn_update.TabStop = false;
            this.btn_update.Click += new System.EventHandler(this.btn_update_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(170, 30);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(190, 26);
            this.label10.TabIndex = 39;
            this.label10.Text = "Pasadena St. F.B. Harrison, Pasay City\r\n\r\n";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(160, 14);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(213, 13);
            this.label9.TabIndex = 38;
            this.label9.Text = "PAMANTASAN NG LUNGSOD NG PASAY\r\n";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(307, 153);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(29, 13);
            this.label8.TabIndex = 37;
            this.label8.Text = "Year";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(54, 153);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(51, 13);
            this.label7.TabIndex = 36;
            this.label7.Text = "Semester";
            // 
            // txtbox_year
            // 
            this.txtbox_year.Location = new System.Drawing.Point(342, 146);
            this.txtbox_year.Name = "txtbox_year";
            this.txtbox_year.Size = new System.Drawing.Size(59, 20);
            this.txtbox_year.TabIndex = 35;
            // 
            // txtbox_course
            // 
            this.txtbox_course.Location = new System.Drawing.Point(221, 146);
            this.txtbox_course.Name = "txtbox_course";
            this.txtbox_course.Size = new System.Drawing.Size(80, 20);
            this.txtbox_course.TabIndex = 34;
            // 
            // txtbox_yr
            // 
            this.txtbox_yr.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(229)))), ((int)(((byte)(125)))));
            this.txtbox_yr.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtbox_yr.Location = new System.Drawing.Point(111, 153);
            this.txtbox_yr.Name = "txtbox_yr";
            this.txtbox_yr.Size = new System.Drawing.Size(67, 13);
            this.txtbox_yr.TabIndex = 33;
            this.txtbox_yr.Text = "2019 - 2020";
            this.txtbox_yr.TextChanged += new System.EventHandler(this.txtbox_yr_TextChanged);
            // 
            // txtbox_sem
            // 
            this.txtbox_sem.Location = new System.Drawing.Point(9, 146);
            this.txtbox_sem.Name = "txtbox_sem";
            this.txtbox_sem.Size = new System.Drawing.Size(39, 20);
            this.txtbox_sem.TabIndex = 32;
            // 
            // txtbox_MI
            // 
            this.txtbox_MI.Location = new System.Drawing.Point(472, 74);
            this.txtbox_MI.Name = "txtbox_MI";
            this.txtbox_MI.Size = new System.Drawing.Size(53, 20);
            this.txtbox_MI.TabIndex = 31;
            // 
            // txtbox_firstname
            // 
            this.txtbox_firstname.Location = new System.Drawing.Point(261, 74);
            this.txtbox_firstname.Name = "txtbox_firstname";
            this.txtbox_firstname.Size = new System.Drawing.Size(205, 20);
            this.txtbox_firstname.TabIndex = 30;
            // 
            // txtbox_surename
            // 
            this.txtbox_surename.Location = new System.Drawing.Point(57, 74);
            this.txtbox_surename.Name = "txtbox_surename";
            this.txtbox_surename.Size = new System.Drawing.Size(198, 20);
            this.txtbox_surename.TabIndex = 29;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(175, 153);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(40, 13);
            this.label6.TabIndex = 28;
            this.label6.Text = "Course";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(488, 97);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(22, 13);
            this.label5.TabIndex = 27;
            this.label5.Text = "MI.";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(344, 97);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(57, 13);
            this.label4.TabIndex = 26;
            this.label4.Text = "First Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(125, 97);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(49, 13);
            this.label3.TabIndex = 25;
            this.label3.Text = "Surname";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(16, 74);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 13);
            this.label2.TabIndex = 24;
            this.label2.Text = "Name";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(54, 43);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(38, 13);
            this.label1.TabIndex = 23;
            this.label1.Text = "ID No.";
            // 
            // txtbox_ID
            // 
            this.txtbox_ID.Location = new System.Drawing.Point(16, 20);
            this.txtbox_ID.Name = "txtbox_ID";
            this.txtbox_ID.Size = new System.Drawing.Size(105, 20);
            this.txtbox_ID.TabIndex = 22;
            this.txtbox_ID.TextChanged += new System.EventHandler(this.txtbox_ID_TextChanged);
            // 
            // txtbox_status
            // 
            this.txtbox_status.Location = new System.Drawing.Point(450, 146);
            this.txtbox_status.Name = "txtbox_status";
            this.txtbox_status.Size = new System.Drawing.Size(59, 20);
            this.txtbox_status.TabIndex = 42;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(407, 153);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(37, 13);
            this.label11.TabIndex = 43;
            this.label11.Text = "Status";
            // 
            // studentBindingSource4
            // 
            this.studentBindingSource4.DataMember = "student";
            this.studentBindingSource4.DataSource = this.nstp_DataSet15;
            // 
            // nstp_DataSet15
            // 
            this.nstp_DataSet15.DataSetName = "nstp_DataSet15";
            this.nstp_DataSet15.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // studentBindingSource3
            // 
            this.studentBindingSource3.DataMember = "student";
            this.studentBindingSource3.DataSource = this.nstp_DataSet6;
            // 
            // nstp_DataSet6
            // 
            this.nstp_DataSet6.DataSetName = "nstp_DataSet6";
            this.nstp_DataSet6.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // nstp_DataSet5
            // 
            this.nstp_DataSet5.DataSetName = "nstp_DataSet5";
            this.nstp_DataSet5.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // nstp_DataSet4
            // 
            this.nstp_DataSet4.DataSetName = "nstp_DataSet4";
            this.nstp_DataSet4.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // nstp_DataSet3
            // 
            this.nstp_DataSet3.DataSetName = "nstp_DataSet3";
            this.nstp_DataSet3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // studentBindingSource2
            // 
            this.studentBindingSource2.DataMember = "student";
            this.studentBindingSource2.DataSource = this.nstp_DataSet3;
            // 
            // studentTableAdapter2
            // 
            this.studentTableAdapter2.ClearBeforeFill = true;
            // 
            // nstp_DataSet1
            // 
            this.nstp_DataSet1.DataSetName = "nstp_DataSet1";
            this.nstp_DataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // studentTableAdapter1
            // 
            this.studentTableAdapter1.ClearBeforeFill = true;
            // 
            // studentTableAdapter3
            // 
            this.studentTableAdapter3.ClearBeforeFill = true;
            // 
            // studentTableAdapter
            // 
            this.studentTableAdapter.ClearBeforeFill = true;
            // 
            // nstp_DataSet
            // 
            this.nstp_DataSet.DataSetName = "nstp_DataSet";
            this.nstp_DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(12, 477);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(73, 13);
            this.label12.TabIndex = 45;
            this.label12.Text = "Back to menu";
            this.label12.Visible = false;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(91, 477);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(111, 13);
            this.label13.TabIndex = 46;
            this.label13.Text = "Successfuly Updated!";
            this.label13.Visible = false;
            // 
            // studentBindingSource1
            // 
            this.studentBindingSource1.DataMember = "student";
            // 
            // studentBindingSource
            // 
            this.studentBindingSource.DataMember = "student";
            // 
            // studentTableAdapter4
            // 
            this.studentTableAdapter4.ClearBeforeFill = true;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(450, 145);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(60, 21);
            this.comboBox1.TabIndex = 47;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(401, 20);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(119, 20);
            this.textBox1.TabIndex = 48;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(436, 43);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(57, 13);
            this.label14.TabIndex = 49;
            this.label14.Text = "Prof Name";
            // 
            // nstp_DataSet22
            // 
            this.nstp_DataSet22.DataSetName = "nstp_DataSet22";
            this.nstp_DataSet22.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // studentBindingSource5
            // 
            this.studentBindingSource5.DataMember = "student";
            this.studentBindingSource5.DataSource = this.nstp_DataSet22;
            // 
            // studentTableAdapter5
            // 
            this.studentTableAdapter5.ClearBeforeFill = true;
            // 
            // dataGridtt
            // 
            this.dataGridtt.AutoGenerateColumns = false;
            this.dataGridtt.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridtt.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iDDataGridViewTextBoxColumn,
            this.surnameDataGridViewTextBoxColumn,
            this.firstnameDataGridViewTextBoxColumn,
            this.mIDataGridViewTextBoxColumn,
            this.semesterDataGridViewTextBoxColumn,
            this.dateDataGridViewTextBoxColumn,
            this.courseDataGridViewTextBoxColumn,
            this.yearDataGridViewTextBoxColumn,
            this.statusDataGridViewTextBoxColumn,
            this.prilemDataGridViewTextBoxColumn,
            this.midtermDataGridViewTextBoxColumn,
            this.finalsDataGridViewTextBoxColumn,
            this.averageDataGridViewTextBoxColumn,
            this.sectionDataGridViewTextBoxColumn,
            this.profDataGridViewTextBoxColumn});
            this.dataGridtt.DataSource = this.studentBindingSource6;
            this.dataGridtt.Location = new System.Drawing.Point(8, 172);
            this.dataGridtt.Name = "dataGridtt";
            this.dataGridtt.Size = new System.Drawing.Size(516, 274);
            this.dataGridtt.TabIndex = 50;
            this.dataGridtt.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick_2);
            // 
            // nstp_DataSet23
            // 
            this.nstp_DataSet23.DataSetName = "nstp_DataSet23";
            this.nstp_DataSet23.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // studentBindingSource6
            // 
            this.studentBindingSource6.DataMember = "student";
            this.studentBindingSource6.DataSource = this.nstp_DataSet23;
            // 
            // studentTableAdapter6
            // 
            this.studentTableAdapter6.ClearBeforeFill = true;
            // 
            // iDDataGridViewTextBoxColumn
            // 
            this.iDDataGridViewTextBoxColumn.DataPropertyName = "ID";
            this.iDDataGridViewTextBoxColumn.HeaderText = "ID";
            this.iDDataGridViewTextBoxColumn.Name = "iDDataGridViewTextBoxColumn";
            // 
            // surnameDataGridViewTextBoxColumn
            // 
            this.surnameDataGridViewTextBoxColumn.DataPropertyName = "Surname";
            this.surnameDataGridViewTextBoxColumn.HeaderText = "Surname";
            this.surnameDataGridViewTextBoxColumn.Name = "surnameDataGridViewTextBoxColumn";
            // 
            // firstnameDataGridViewTextBoxColumn
            // 
            this.firstnameDataGridViewTextBoxColumn.DataPropertyName = "Firstname";
            this.firstnameDataGridViewTextBoxColumn.HeaderText = "Firstname";
            this.firstnameDataGridViewTextBoxColumn.Name = "firstnameDataGridViewTextBoxColumn";
            // 
            // mIDataGridViewTextBoxColumn
            // 
            this.mIDataGridViewTextBoxColumn.DataPropertyName = "MI";
            this.mIDataGridViewTextBoxColumn.HeaderText = "MI";
            this.mIDataGridViewTextBoxColumn.Name = "mIDataGridViewTextBoxColumn";
            // 
            // semesterDataGridViewTextBoxColumn
            // 
            this.semesterDataGridViewTextBoxColumn.DataPropertyName = "Semester";
            this.semesterDataGridViewTextBoxColumn.HeaderText = "Semester";
            this.semesterDataGridViewTextBoxColumn.Name = "semesterDataGridViewTextBoxColumn";
            // 
            // dateDataGridViewTextBoxColumn
            // 
            this.dateDataGridViewTextBoxColumn.DataPropertyName = "Date";
            this.dateDataGridViewTextBoxColumn.HeaderText = "Date";
            this.dateDataGridViewTextBoxColumn.Name = "dateDataGridViewTextBoxColumn";
            // 
            // courseDataGridViewTextBoxColumn
            // 
            this.courseDataGridViewTextBoxColumn.DataPropertyName = "Course";
            this.courseDataGridViewTextBoxColumn.HeaderText = "Course";
            this.courseDataGridViewTextBoxColumn.Name = "courseDataGridViewTextBoxColumn";
            // 
            // yearDataGridViewTextBoxColumn
            // 
            this.yearDataGridViewTextBoxColumn.DataPropertyName = "Year";
            this.yearDataGridViewTextBoxColumn.HeaderText = "Year";
            this.yearDataGridViewTextBoxColumn.Name = "yearDataGridViewTextBoxColumn";
            // 
            // statusDataGridViewTextBoxColumn
            // 
            this.statusDataGridViewTextBoxColumn.DataPropertyName = "Status";
            this.statusDataGridViewTextBoxColumn.HeaderText = "Status";
            this.statusDataGridViewTextBoxColumn.Name = "statusDataGridViewTextBoxColumn";
            // 
            // prilemDataGridViewTextBoxColumn
            // 
            this.prilemDataGridViewTextBoxColumn.DataPropertyName = "Prilem";
            this.prilemDataGridViewTextBoxColumn.HeaderText = "Prilem";
            this.prilemDataGridViewTextBoxColumn.Name = "prilemDataGridViewTextBoxColumn";
            // 
            // midtermDataGridViewTextBoxColumn
            // 
            this.midtermDataGridViewTextBoxColumn.DataPropertyName = "Midterm";
            this.midtermDataGridViewTextBoxColumn.HeaderText = "Midterm";
            this.midtermDataGridViewTextBoxColumn.Name = "midtermDataGridViewTextBoxColumn";
            // 
            // finalsDataGridViewTextBoxColumn
            // 
            this.finalsDataGridViewTextBoxColumn.DataPropertyName = "Finals";
            this.finalsDataGridViewTextBoxColumn.HeaderText = "Finals";
            this.finalsDataGridViewTextBoxColumn.Name = "finalsDataGridViewTextBoxColumn";
            // 
            // averageDataGridViewTextBoxColumn
            // 
            this.averageDataGridViewTextBoxColumn.DataPropertyName = "Average";
            this.averageDataGridViewTextBoxColumn.HeaderText = "Average";
            this.averageDataGridViewTextBoxColumn.Name = "averageDataGridViewTextBoxColumn";
            // 
            // sectionDataGridViewTextBoxColumn
            // 
            this.sectionDataGridViewTextBoxColumn.DataPropertyName = "Section";
            this.sectionDataGridViewTextBoxColumn.HeaderText = "Section";
            this.sectionDataGridViewTextBoxColumn.Name = "sectionDataGridViewTextBoxColumn";
            // 
            // profDataGridViewTextBoxColumn
            // 
            this.profDataGridViewTextBoxColumn.DataPropertyName = "Prof";
            this.profDataGridViewTextBoxColumn.HeaderText = "Prof";
            this.profDataGridViewTextBoxColumn.Name = "profDataGridViewTextBoxColumn";
            // 
            // edit
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(229)))), ((int)(((byte)(125)))));
            this.ClientSize = new System.Drawing.Size(533, 494);
            this.Controls.Add(this.dataGridtt);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.txtbox_status);
            this.Controls.Add(this.btn_cancel);
            this.Controls.Add(this.btn_update);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txtbox_year);
            this.Controls.Add(this.txtbox_course);
            this.Controls.Add(this.txtbox_yr);
            this.Controls.Add(this.txtbox_sem);
            this.Controls.Add(this.txtbox_MI);
            this.Controls.Add(this.txtbox_firstname);
            this.Controls.Add(this.txtbox_surename);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtbox_ID);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "edit";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "edit";
            this.Load += new System.EventHandler(this.edit_Load);
            ((System.ComponentModel.ISupportInitialize)(this.btn_cancel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btn_update)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentBindingSource4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nstp_DataSet15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentBindingSource3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nstp_DataSet6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nstp_DataSet5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nstp_DataSet4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nstp_DataSet3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nstp_DataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nstp_DataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nstp_DataSet22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentBindingSource5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridtt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nstp_DataSet23)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentBindingSource6)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox btn_cancel;
        private System.Windows.Forms.PictureBox btn_update;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtbox_year;
        private System.Windows.Forms.TextBox txtbox_course;
        private System.Windows.Forms.TextBox txtbox_yr;
        private System.Windows.Forms.TextBox txtbox_sem;
        private System.Windows.Forms.TextBox txtbox_MI;
        private System.Windows.Forms.TextBox txtbox_firstname;
        private System.Windows.Forms.TextBox txtbox_surename;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtbox_ID;
        private System.Windows.Forms.TextBox txtbox_status;
        private System.Windows.Forms.Label label11;
        private nstp_DataSet5 nstp_DataSet5;
        private System.Windows.Forms.BindingSource studentBindingSource2;
        private nstp_DataSet3 nstp_DataSet3;
        private nstp_DataSet4 nstp_DataSet4;
        private nstp_DataSet3TableAdapters.studentTableAdapter studentTableAdapter2;
        private System.Windows.Forms.BindingSource studentBindingSource1;
        private nstp_DataSet1 nstp_DataSet1;
        private nstp_DataSetTableAdapters.studentTableAdapter studentTableAdapter;
        private System.Windows.Forms.BindingSource studentBindingSource;
        private nstp_DataSet nstp_DataSet;
        private nstp_DataSet1TableAdapters.studentTableAdapter studentTableAdapter1;
        private nstp_DataSet6 nstp_DataSet6;
        private System.Windows.Forms.BindingSource studentBindingSource3;
        private nstp_DataSet6TableAdapters.studentTableAdapter studentTableAdapter3;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private nstp_DataSet15 nstp_DataSet15;
        private System.Windows.Forms.BindingSource studentBindingSource4;
        private nstp_DataSet15TableAdapters.studentTableAdapter studentTableAdapter4;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label14;
        private nstp_DataSet22 nstp_DataSet22;
        private System.Windows.Forms.BindingSource studentBindingSource5;
        private nstp_DataSet22TableAdapters.studentTableAdapter studentTableAdapter5;
        private System.Windows.Forms.DataGridView dataGridtt;
        private nstp_DataSet23 nstp_DataSet23;
        private System.Windows.Forms.BindingSource studentBindingSource6;
        private nstp_DataSet23TableAdapters.studentTableAdapter studentTableAdapter6;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn surnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn firstnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn mIDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn semesterDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn courseDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn yearDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn statusDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn prilemDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn midtermDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn finalsDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn averageDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sectionDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn profDataGridViewTextBoxColumn;
    }
}