﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace my_app
{
    class GlobalVariable
    {
        public static DataTable LoggedInUser { get; set; }
    }
}
