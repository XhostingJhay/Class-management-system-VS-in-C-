﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace my_app
{
    class Class1
    {
        public enum Activity
        {
            LOGIN,
            LOGOUT,
            CREATED,
            MODIFIED,
            DELETED
        }
    }
}
